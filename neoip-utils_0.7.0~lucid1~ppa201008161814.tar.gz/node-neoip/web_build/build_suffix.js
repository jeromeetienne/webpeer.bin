/**
 * This file will be happened to webpeer.js during the builder
*/

// exports the public symbols
GLOBAL.webpeer	= require('./webpeer');

// end of the global closure
})(window);